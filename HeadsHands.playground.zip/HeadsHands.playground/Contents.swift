import Foundation

class Creature {
    var name: String
    var health: Double
    var attackValue: Int
    var protectionValue: Int
    var damageRange: ClosedRange<Int>
    
    init(name: String, initialHealth: Double, attackValue: Int, protectionValue: Int, damageRange: ClosedRange<Int>) {
	   self.name = name
	   self.health = max(initialHealth, 0)
	   self.attackValue = (1...30).contains(attackValue) ? attackValue : (attackValue < 1 ? 1 : 30)
	   self.protectionValue = (1...30).contains(protectionValue) ? protectionValue : (protectionValue < 1 ? 1 : 30)
	   self.damageRange = damageRange
}
    
    func attack(hisGoal: Creature) {
	   print("\(name) атакует")
	   
	   let impactDamage = max(attackValue - hisGoal.protectionValue + 1, 1)
	   let diceRolls = Dice.roll(impactDamage)
	   
	   if diceRolls.contains(where: { $0 >= 5 }) {
		  let damage = Int.random(in: self.damageRange)
		  hisGoal.health -= Double(damage)
		  print("Удар успешен! \(hisGoal.name) теряет \(damage) здоровья")
				} else {
		  print("Удар не успешен. \(hisGoal.name) не получает урона")
			 }
	   
	   print("Текущее состояние здоровья \(hisGoal.name) составляет \(hisGoal.health)")
	   }
    
    func getDamageRange() -> ClosedRange<Int> {
	   return self.damageRange
    }
}


class Player: Creature {
    var healingCount: Int
    let maxHealingCount: Int = 4
    let healingPercentage: Double = 0.3
    
     init(name: String, initialHealth: Double, attackValue: Int, protectionValue: Int) {
	   self.healingCount = 0
	   super.init(name: name, initialHealth: initialHealth, attackValue: attackValue, protectionValue: protectionValue, damageRange: 1...30)
    }
    
    func heal() {
	   if healingCount < maxHealingCount {
		  let healedAmount = health * healingPercentage
		  health += healedAmount
		  print("Исцеление прошло успешно. Текущее здоровье \(name) составляет \(health)")
		  healingCount += 1
		  } else {
		  print("Для повторного исцеления, пополните баланс")
	   }
    }
}

class Monster: Creature {
    init(name: String, initialHealth: Double, attackValue: Int, protectionValue: Int) {
	   let damageRange = 1...30
	   super.init(name: name, initialHealth: initialHealth, attackValue: attackValue, protectionValue: protectionValue, damageRange: damageRange)
    }
}

struct Dice {
    static func roll(_ count: Int) -> [Int] {
	   var rolls = [Int]()
	   for _ in 0..<count {
		  rolls.append(Int.random(in: 1...6))
	   }
	   return rolls
    }
}


let player = Player(name: "Radik", initialHealth: 90, attackValue: -200, protectionValue: 15)
let monster = Monster(name: "Purin", initialHealth: 90, attackValue: 250, protectionValue: 20)

var round = 1

//MARK:- game logic

while monster.health >= 0 && player.health >= 0 {
    print("Раунд под номером \(round)")
    
    let playerDiceRolls = Dice.roll(2)
    let monsterDiceRolls = Dice.roll(2)
    
    print("Здоровье монстра равняется = \(monster.health)")
    print("Здоровье игрока равняется = \(player.health)")
    
    player.attack(hisGoal: monster)
    monster.attack(hisGoal: player)
    
    if player.health <= 0 {
	   print("Победил монстр")
	   }
    
    if monster.health <= 0 {
	   print("Победил игрок")
    }
    
    player.heal()
    
    round += 1
    print()
    sleep(3)
}

